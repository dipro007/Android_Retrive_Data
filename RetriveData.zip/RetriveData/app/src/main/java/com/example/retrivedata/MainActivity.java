package com.example.retrivedata;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


public class MainActivity extends AppCompatActivity {
        FirebaseDatabase mdatabase;
        DatabaseReference mref;
        FirebaseStorage mstorage;
        ImageButton imagebutton;
        EditText edtfirst,edtlast;
        Button btn;

        private static final int Gallery_code = 1;
        Uri iamgeUrl = null;

        ProgressDialog progressDialog;





        @Override
        protected void onCreate( Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                imagebutton = (ImageButton)findViewById(R.id.imageButton);
                edtfirst = (EditText) findViewById(R.id.editfirsttname);
                edtlast = (EditText) findViewById(R.id.editlasttname);
                btn = (Button)findViewById(R.id.btninsert);

                mdatabase = FirebaseDatabase.getInstance();
                mref = mdatabase.getReference().child("Movie Media");
                mstorage = FirebaseStorage.getInstance();
                progressDialog = new ProgressDialog(this);

                imagebutton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                                intent.setType("image/*");
                                startActivityForResult(intent,Gallery_code);

                        }
                });
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
                super.onActivityResult(requestCode, resultCode, data);

                if (requestCode == Gallery_code && resultCode == RESULT_OK);
                {
                        iamgeUrl = data.getData();
                        imagebutton.setImageURI(iamgeUrl);
                }
                btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                              final   String fn = edtfirst.getText().toString().trim();
                              final String ln = edtlast.getText().toString().trim();

                                if (!(fn.isEmpty() && ln.isEmpty() && iamgeUrl!=null))
                                {
                                        progressDialog.setTitle("Uploading information...");
                                        progressDialog.show();

                                        StorageReference filepath = mstorage.getReference().child("Image Post").child(iamgeUrl.getLastPathSegment());
                                        filepath.putFile(iamgeUrl).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot)
                                                {
                                                        Task<Uri> downloadUrl = taskSnapshot.getStorage().getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Uri> task) {
                                                                        String t = task.getResult().toString();

                                                                        DatabaseReference newPost = mref.push();

                                                                        newPost.child("Actorname").setValue(fn);
                                                                        newPost.child("Moviename").setValue(ln);
                                                                        newPost.child("image").setValue(task.getResult().toString());
                                                                        progressDialog.dismiss();

                                                                        Intent intent = new Intent(MainActivity.this,RetriveDataRecyclerView.class);
                                                                        startActivity(intent);


                                                                }
                                                        });
                                                }
                                        });

                                }


                        }
                });
        }
}






