package com.example.retrivedata;

public class MovieMedia {
    String Actorname;
    String Moviename;
    String image;

    public MovieMedia() {

    }

    public MovieMedia(String fisrtname, String lastName, String image) {
        Actorname = fisrtname;
        Moviename = lastName;
        this.image = image;
    }

    public String getActorname() {
        return Actorname;
    }

    public void setActorname(String actorname) {
        Actorname = actorname;
    }

    public String getMoviename() {
        return Moviename;
    }

    public void setMoviename(String moviename) {
        Moviename = moviename;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
