package com.example.retrivedata;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.List;

public class RetriveDataRecyclerView extends AppCompatActivity {


    FirebaseDatabase mdatabase;
    DatabaseReference mref;
    FirebaseStorage mstorage;
    RecyclerView recyclerView;
    MyAdapter myAdapter;
    List<MovieMedia> movieMediaList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.retrive_data_recycler_view);

        mdatabase = FirebaseDatabase.getInstance();
        mref = mdatabase.getReference().child("Movie Media");
        mstorage = FirebaseStorage.getInstance();
        recyclerView =(RecyclerView)findViewById(R.id.recview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        movieMediaList = new ArrayList<MovieMedia>();
        myAdapter  = new MyAdapter(RetriveDataRecyclerView.this,movieMediaList);
        recyclerView.setAdapter(myAdapter);

        mref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                MovieMedia movieMedia = snapshot.getValue(MovieMedia.class);
                movieMediaList.add(movieMedia);

                myAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}