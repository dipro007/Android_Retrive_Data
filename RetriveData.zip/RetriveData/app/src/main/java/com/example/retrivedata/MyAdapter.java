package com.example.retrivedata;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {


    Context context;
    List<MovieMedia> movielist;


    public MyAdapter(Context context, List<MovieMedia> movielist) {
        this.context = context;
        this.movielist = movielist;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        View  v = LayoutInflater.from(parent.getContext()).inflate(R.layout.design_row,parent,false);


        return new ViewHolder(v);


    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        MovieMedia movieMedia = movielist.get(position);
        holder.textView2.setText("Movie name:\n"+movieMedia.getMoviename());
        holder.textView1.setText("Actor's name:\n"+movieMedia.getActorname());


        String imageUri = null;
        imageUri = movieMedia.getImage();
        Picasso.get().load(imageUri).into(holder.imageView);



    }

    @Override
    public int getItemCount() {
        return movielist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView textView1,textView2;



        public ViewHolder(@NonNull View itemView) {


            super(itemView);
            imageView = itemView.findViewById(R.id.img);
            textView1 = itemView.findViewById(R.id.firstname);
            textView2 = itemView.findViewById(R.id.lastname);


        }
    }
}
